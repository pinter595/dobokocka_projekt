function rollDice() {
    const diceRoll = Math.floor(Math.random() * 6) + 1;
    const diceImage = document.getElementById("diceImage");
    const resultText = document.getElementById("result");
    const diceSound = document.getElementById("diceSound");
    const jackpotSound = document.getElementById("jackpotSound");


    diceSound.currentTime = 0;
    diceSound.play();


    diceImage.classList.add("rolling");


    setTimeout(() => {
        diceImage.src = diceRoll + ".png";
        diceImage.classList.remove("rolling");
        resultText.textContent = `Eredmény: ${diceRoll}`;


        if (diceRoll === 6) {
            jackpotSound.currentTime = 0;
            jackpotSound.play();
        }
    }, 600);
}


document.querySelector("button").addEventListener("click", function() {
    const clickSound = document.getElementById("clickSound");
    clickSound.currentTime = 0;
    clickSound.play();
});
